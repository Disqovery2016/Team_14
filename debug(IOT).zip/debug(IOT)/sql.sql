CREATE TABLE `w` (
  `id` INT AUTO_INCREMENT,
  `weight` VARCHAR(20),
  `type` VARCHAR(20),
  `user` VARCHAR(20),
  PRIMARY KEY (`id`)
);
