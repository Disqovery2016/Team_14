                                                /**********************Read Me*************************/
1.we have created the web applicaton by avoiding the third party server.
2.we hosted our web site in hostinger.in
3.The things are done by us to interact and test the IOT Platform as a stage one.
right now we are doing some changes to our code whic is required,
4.at the same time our web developrs are working in designing the official web site.
5.once if both are get ready we are going to integrate to wind the application.



                                                 /**********************IMPORTANT*********************/
												 
												 
												 
1.We are using the wifi(ESP 8266 NODE MCU) module inorder to make communication with our web server to do IOT.
2.Esp 8266 will provide it's open source library,to make it user to develop a wide range of applications.
3.Any one is free to use and edit the Library files,So we have editied the Source code Reference to make the model and used in 1.ino(arduino) file.
4.In order to design the web page in HTML and PHP files we have used the fallowing Sites as a Referance:

             http://www.w3schools.com/  Websites
			 
			 
			 Head First With PHP,Head First With SQL,Head First With HTML,Head First With CSS Books.and there official site is http://www.headfirstlabs.com/
			 
These referances are helping us a lot to make complete the task in a Given time.

To Test the IOT Application before connecting it to our main WEB Database

Format of Data Upload Link: 
v16he2v4.esy.es/set.php?user=9998844234&type=blue&weight=4.51
v16he2v4.esy.es/a.php?user=9998844234&type=blue&weight=4.51
v16he2v4.esy.es/displat.php

			 




